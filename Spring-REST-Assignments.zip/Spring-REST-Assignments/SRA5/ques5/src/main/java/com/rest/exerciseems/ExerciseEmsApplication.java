package com.rest.exerciseems;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExerciseEmsApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExerciseEmsApplication.class, args);
		System.out.println("Started... ");
	}

}
