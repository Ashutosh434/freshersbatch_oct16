package A2.Q6;

public class DessertShop {
    public static void main(String[] args) {
        Candy item1 = new Candy("Peanut", 2.25, 3.99);
        Cookie item2 = new Cookie("Cookies", 4, 3.99);
        IceCream item3 = new IceCream("Ice Cream", 2, 1.05, 0.45);

        System.out.println(item1);
        System.out.println(item2);
        System.out.println(item3);

    }
}





