package A3.StringClassAssignments;

public class StringPractice2 {
    public static void main(String[] args) {

        String str1 = "Hello ";
        String str2 = "How You Doing?";
        String s1 = str1.concat(str2);


        System.out.println("String after concatenation: " + s1);
    }
}
