package A3.StringClassAssignments;

public class StringPractice1 {
    public static void main(String[] args) {

        String str = "Hello World";
        int length = str.length();

        System.out.println("length of the string is: " + length);
    }
}