package A6;

import java.util.Collections;
import java.util.Map;
import java.util.TreeMap;


public class Collections1 {
    long phoneNumber;
    String contactName, email;
    char gender;

    public Collections1(long phoneNumber, String contactName, String email, char gender) {
        this.phoneNumber = phoneNumber;
        this.contactName = contactName;
        this.email = email;
        this.gender = gender;
    }

}

class Collections2 {
    public static void main(String[] args) {
        Map<Long, Collections1> map = new TreeMap<>(Collections.reverseOrder());
        Collections1 c1 = new Collections1(985461155L, "Ashutosh", "xyz.com", 'M');
        Collections1 c2 = new Collections1(412014776L, "Vineet", "abcd@capg.com", 'M');
        Collections1 c3 = new Collections1(336478666L, "Tarun", "wergmail.com", 'M');
        Collections1 c4 = new Collections1(845841256L, "Aryan", "dsds@capgemini.com", 'M');
        map.put(1L, c1);
        map.put(2L, c2);
        map.put(3L, c3);
        map.put(4L, c4);


        for (Map.Entry<Long, Collections1> entry : map.entrySet()) {
            long key = entry.getKey();
            Collections1 c5 = entry.getValue();
            System.out.println(key + " Details:");//prints all keys

            System.out.println("phone number: " + c5.phoneNumber + " contact name: " + c5.contactName + "email: " + c5.email + " gender: " + c5.gender);
        }
        System.out.print(" ");

    }
}