package A6.Q3;

import java.util.TreeSet;

class TestComparator {
    public static void main(String[] args) {

        // Creating the TreeSet with Comparator object passed
        // as the parameter which will sort the user defined
        // objects of TreeSet

        var treeSet = new TreeSet<Employee>();
        var e1 = new Employee(1, "Ashutosh", "CSE", 40000);
        var e2 = new Employee(2, "Tarun", "CSE", 35000);
        var e3 = new Employee(3, "Aryan", "CSE", 45000);
        var e4 = new Employee(4, "Vishal", "CSE", 75000);
        var e5 = new Employee(5, "Vineet", "CSE", 10000);

        Employee.field = "name";


        treeSet.add(e1);
        treeSet.add(e4);
        treeSet.add(e2);
        treeSet.add(e3);
        treeSet.add(e5);
        Employee e = null;
        for (var h : treeSet) {
            e = h;
            System.out.println(e.getName());
        }
    }
}


