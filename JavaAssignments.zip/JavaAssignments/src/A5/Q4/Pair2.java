package A5.Q4;

import java.util.HashMap;

public class Pair2 {
    public static void main(String[] args) {
        HashMap<String, java.util.Date> myObj = new HashMap<>();
        myObj.put("TODAY  IS ", new java.util.Date());

        // Print and display TIMINGS of MyObj//
        System.out.println("TIME AND DATE OF MyObj : "
                + myObj);

    }
}