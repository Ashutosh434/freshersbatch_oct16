package A7;

import java.util.ArrayList;


class Q6 {
    public static void main(String[] args) {
        ArrayList<String> replace = new ArrayList<>();
        replace.add("ashutosh");
        replace.add("tarun");
        replace.add("aryan");
        replace.add("vishal");
        replace.add("vineet");

        replace.replaceAll((String) ->
                //replacing replace elements to uppercase//
                String.equals(replace) ? String : String.toUpperCase());

        System.out.println(replace);
    }
}